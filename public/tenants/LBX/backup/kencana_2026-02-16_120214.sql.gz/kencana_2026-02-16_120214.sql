/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.27-MariaDB, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: kencana
-- ------------------------------------------------------
-- Server version	10.5.27-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accountingcategories`
--

DROP TABLE IF EXISTS `accountingcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountingcategories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountingcategories`
--

LOCK TABLES `accountingcategories` WRITE;
/*!40000 ALTER TABLE `accountingcategories` DISABLE KEYS */;
INSERT INTO `accountingcategories` VALUES (1,'bensin',NULL,NULL,NULL),(2,'konsumsi',NULL,NULL,NULL),(3,'atk',NULL,NULL,NULL),(4,'pendapatan usaha',NULL,NULL,NULL),(5,'hutang',NULL,NULL,NULL),(6,'piutang',NULL,NULL,NULL);
/*!40000 ALTER TABLE `accountingcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountings`
--

DROP TABLE IF EXISTS `accountings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `id_category` int(11) NOT NULL,
  `income` int(11) NOT NULL DEFAULT 0,
  `expense` int(11) DEFAULT 0,
  `account_payable` int(11) NOT NULL DEFAULT 0,
  `account_recievable` int(11) NOT NULL DEFAULT 0,
  `reff` int(11) NOT NULL DEFAULT 0,
  `note` varchar(255) NOT NULL,
  `created_by` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountings`
--

LOCK TABLES `accountings` WRITE;
/*!40000 ALTER TABLE `accountings` DISABLE KEYS */;
/*!40000 ALTER TABLE `accountings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `akuns`
--

DROP TABLE IF EXISTS `akuns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `akuns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `akun_code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `parent` varchar(255) DEFAULT NULL,
  `tax` int(11) NOT NULL DEFAULT 0,
  `tax_value` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `akuns`
--

LOCK TABLES `akuns` WRITE;
/*!40000 ALTER TABLE `akuns` DISABLE KEYS */;
INSERT INTO `akuns` VALUES (1,'1-10001','kas','kas & bank','aktiva lancar','aktiva',NULL,0,0,'2021-09-18 13:59:37','0000-00-00 00:00:00',NULL),(5,'1-10100','piutang usaha','akun piutang','aktiva lancar','aktiva',NULL,0,0,'2021-09-18 13:59:37','0000-00-00 00:00:00',NULL),(22,'4-40000','pendapatan','pendapatan','pendapatan','pendapatan',NULL,0,0,'2021-09-19 00:47:50','0000-00-00 00:00:00',NULL),(67,'2-20500','PPN Keluaran','kewajiban jangka pendek','utang jangka pendek','kewajiban',NULL,1,11,'2024-12-13 12:22:38','0000-00-00 00:00:00',NULL),(73,'1-10006','KAS BUMDES','kas & bank','','aktiva','1-10001',0,0,'2025-01-19 07:34:32','2025-01-19 15:34:55',NULL),(85,'1-10000','Kas Tunai','kas & bank','','aktiva',NULL,0,0,'2025-01-28 01:30:54','2025-01-28 09:32:26',NULL),(86,'1-10003','Bank','kas & bank','','aktiva',NULL,0,0,'2025-01-28 01:32:26','2025-01-28 09:33:19',NULL),(88,'1-10005','Kas Office','kas & bank','','aktiva','1-10000',0,0,'2025-01-28 01:38:17','2025-01-28 09:40:23',NULL),(91,'1-10009','Bank BNI','kas & bank','','aktiva','1-10003',0,0,'2025-01-28 01:41:20','2025-01-28 09:42:05',NULL),(92,'1-10010','Bank BRI','kas & bank','','aktiva','1-10003',0,0,'2025-01-28 01:42:05','2025-01-28 09:42:30',NULL),(93,'1-10011','Bank BPD','kas & bank','','aktiva','1-10003',0,0,'2025-01-28 01:42:30','2025-01-28 09:42:54',NULL),(106,'1-10024','Bank BCA','kas & bank','','aktiva','1-10003',0,0,'2025-01-28 02:11:46','2025-01-28 10:11:59',NULL),(131,'1-10105','Piutang BTS','akun piutang','','aktiva',NULL,0,0,'2025-06-13 02:47:03','2025-06-13 10:50:35',NULL),(132,'1-10106','Piutang Lain Lain','akun piutang','','aktiva',NULL,0,0,'2025-06-13 02:50:36','2025-06-13 10:51:53',NULL),(133,'1-10107','Piutang Karyawan','akun piutang','','aktiva',NULL,0,0,'2025-06-13 02:51:54','2025-06-13 10:52:41',NULL),(137,'1-10302','Prepaid Tax','aktiva lainnya','','aktiva',NULL,0,0,'2025-06-13 02:55:35','2025-06-13 10:55:57',NULL),(138,'1-10303','Beban Dibayar Dimuka','aktiva lainnya','','aktiva',NULL,0,0,'2025-06-13 02:55:59','2025-06-13 10:56:34',NULL),(139,'1-10500','PPN Masukan','aktiva lainnya','','aktiva',NULL,0,0,'2025-06-13 02:56:35','2025-06-13 10:57:13',NULL),(140,'1-10503','Pajak Dibayar Dimuka - PPH 25','aktiva lainnya','','aktiva',NULL,0,0,'2025-06-13 02:57:15','2025-06-13 10:58:49',NULL),(142,'1-10200','Persediaan Barang','persediaan','','aktiva',NULL,0,0,'2025-06-13 07:05:40','2025-06-13 15:06:08',NULL),(143,'1-10700','Aset Tetap - Tanah','aktiva tetap','','aktiva',NULL,0,0,'2025-06-13 07:06:44','2025-06-13 15:08:50',NULL),(144,'1-10701','Aset Tetap - Bangunan','aktiva tetap','','aktiva',NULL,0,0,'2025-06-13 07:08:52','2025-06-13 15:09:31',NULL),(145,'1-10703','Aset Tetap - Kendaraan','aktiva tetap','','aktiva',NULL,0,0,'2025-06-13 07:09:33','2025-06-13 15:10:12',NULL),(146,'1-10704','Aset Tetap - Mesin & Peralalatan','aktiva tetap','','aktiva',NULL,0,0,'2025-06-13 07:10:14','2025-06-13 15:11:15',NULL),(147,'1-10705','Aset Tetap - Perlengkapan Kantor','aktiva tetap','','aktiva',NULL,0,0,'2025-06-13 07:11:17','2025-06-13 15:11:51',NULL),(148,'1-10751','Akumulasi Penyusutan - Bangunan','depresiasi dan amortisasi','','aktiva',NULL,0,0,'2025-06-13 07:11:54','2025-06-13 15:16:49',NULL),(149,'1-10753','Akumulasi Penyusutan - Kendaraan','depresiasi dan amortisasi','','aktiva',NULL,0,0,'2025-06-13 07:16:51','2025-06-13 15:19:51',NULL),(151,'1-10754','Akumulasi Penyusutan - Mesin dan Peralatan','depresiasi dan amortisasi','','aktiva',NULL,0,0,'2025-06-13 07:21:22','2025-06-13 15:22:37',NULL),(152,'1-10755','Akumulasi Penyusutan - Peralatan Kantor','depresiasi dan amortisasi','','aktiva',NULL,0,0,'2025-06-13 07:22:39','2025-06-13 15:23:24',NULL),(153,'2-20101','Hutang Fee','akun hutang','','kewajiban',NULL,0,0,'2025-06-13 07:24:57','2025-06-13 15:25:38',NULL),(160,'2-20207','Deposit','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-13 08:13:03','2025-06-13 16:19:38',NULL),(162,'2-20114','Titipan BPJS Karyawan','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-13 08:23:23','2025-06-13 16:24:21',NULL),(175,'2-20201','Intercompanise Contra','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-18 09:25:49','2025-06-18 17:26:53',NULL),(176,'2-20203','Pendapatan Diterima Di Muka','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-18 09:26:57','2025-06-18 17:42:11',NULL),(178,'2-20501','Titipan PPN Keluaran','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-18 10:21:06','2025-06-18 18:21:24',NULL),(179,'2-20502','Hutang Pajak - PPH 23','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-18 10:21:29','2025-06-18 18:22:18',NULL),(180,'2-20503','Hutang Pajak Lainnya','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-06-18 10:23:03','2025-06-18 18:26:39',NULL),(181,'3-30000','Modal Saham','ekuitas','','ekuitas',NULL,0,0,'2025-06-18 10:26:44','2025-06-18 18:30:54',NULL),(182,'3-30002','Ikhtisar Laba/Rugi','ekuitas','','ekuitas',NULL,0,0,'2025-06-18 10:30:58','2025-06-18 18:32:00',NULL),(183,'3-30001','Tambahan Modal Disetor','ekuitas','','ekuitas',NULL,0,0,'2025-06-18 10:32:04','2025-06-18 18:32:34',NULL),(184,'3-30003','Prive','ekuitas','','ekuitas',NULL,0,0,'2025-06-18 10:32:39','2025-06-18 18:33:41',NULL),(185,'3-30100','Laba Ditahan','ekuitas','','ekuitas',NULL,0,0,'2025-06-18 10:33:46','2025-06-18 18:34:26',NULL),(186,'3-30200','Deviden','ekuitas','','ekuitas',NULL,0,0,'2025-06-19 07:38:58','2025-06-19 15:44:53',NULL),(187,'4-40101','Pendapatan Project','pendapatan','','pendapatan',NULL,0,0,'2025-06-19 07:45:43','2025-06-19 15:46:16',NULL),(188,'4-40102','Pendapatan Bulanan','pendapatan','','pendapatan',NULL,0,0,'2025-06-19 07:46:21','2025-06-19 15:46:42',NULL),(189,'4-40103','Pendapatan Register','pendapatan','','pendapatan',NULL,0,0,'2025-06-19 07:47:26','2025-06-19 15:48:04',NULL),(190,'4-40104','Pendapatan Voucher','pendapatan','','pendapatan',NULL,0,0,'2025-06-19 07:48:09','2025-06-19 15:58:57',NULL),(191,'4-40105','Pendapataan Alat','pendapatan','','pendapatan',NULL,0,0,'2025-06-19 07:59:54','2025-06-19 16:00:19',NULL),(195,'8-80004','Beban Bunga','beban lainnya','','beban',NULL,0,0,'2025-07-08 03:06:23','2025-07-08 11:08:07',NULL),(196,'6-60001','Listrik','beban','','beban',NULL,0,0,'2025-07-08 03:37:28','2025-07-08 11:55:36',NULL),(197,'2-20504','Titipan Pelanggan','kewajiban lancar lainnya','','kewajiban',NULL,0,0,'2025-07-08 03:55:43','2025-07-08 12:11:22',NULL),(198,'7-70003','Other Income','pendapatan lainnya','','pendapatan',NULL,0,0,'2025-07-08 06:09:33','2025-07-08 14:10:38',NULL),(199,'6-60103','Konsumsi','beban','','beban',NULL,0,0,'2025-07-08 06:10:45','2025-07-08 14:13:07',NULL),(200,'6-60226','Beban Transport','beban','','beban',NULL,0,0,'2025-07-08 06:13:14','2025-07-08 14:15:46',NULL),(201,'5-50202','Beban Pembelian','harga pokok penjualan','','beban',NULL,0,0,'2025-07-08 06:15:53','2025-07-08 14:33:15',NULL),(202,'6-60242','Perlengkapan Kebersihan','beban','','beban',NULL,0,0,'2025-07-09 04:57:07','2025-07-09 13:00:40',NULL),(203,'6-60000','Suka Duka','beban','','beban',NULL,0,0,'2025-07-09 06:04:23','2025-07-09 15:54:58',NULL),(204,'6-60105','Pengobatan','beban','','beban',NULL,0,0,'2025-07-09 07:55:06','2025-07-09 15:55:59',NULL),(205,'5-50300','Beban Pengiriman','harga pokok penjualan','','beban',NULL,0,0,'2025-07-09 07:56:07','2025-07-09 16:10:30',NULL),(206,'6-60002','Iklan dan Promosi','beban','','beban',NULL,0,0,'2025-07-09 08:26:15','2025-07-09 16:26:26',NULL),(207,'2-20127','Hutang CV Prisma Mitra Buana','akun hutang','','kewajiban',NULL,0,0,'2025-07-09 09:56:08','2025-07-09 17:56:41',NULL),(208,'8-80000','Beban Lain Lain (Other Income )','beban lainnya','','beban',NULL,0,0,'2025-07-11 07:31:12','2025-07-11 15:31:45',NULL),(209,'5-50500','Bandwith Alus','harga pokok penjualan','','beban',NULL,0,0,'2025-07-11 07:31:54','2025-07-11 16:55:59',NULL),(210,'6-60107','BPJS Ketenagakerjaan','beban','','beban',NULL,0,0,'2025-07-12 02:31:10','2025-07-12 10:32:02',NULL),(211,'6-60233','BPJS Kesehatan','beban','','beban',NULL,0,0,'2025-07-12 02:32:10','2025-07-12 10:33:53',NULL),(213,'6-60403','Beban Sewa Lain-lain','beban','','beban',NULL,0,0,'2025-07-16 04:19:00','2025-07-16 12:20:03',NULL),(214,'6-60203','Perbaikan dan Pemeliharaan','beban','','beban',NULL,0,0,'2025-07-16 04:20:12','2025-07-16 12:26:53',NULL),(215,'5-50204','Beban CCTV','harga pokok penjualan','','beban',NULL,0,0,'2025-07-16 05:05:30','2025-07-16 13:19:39',NULL),(216,'4-40108','Pendapatan CCTV','pendapatan','','pendapatan',NULL,0,0,'2025-07-17 06:57:53','2025-07-17 15:00:11',NULL),(217,'6-60241','Beban Kendaraan','beban','','beban',NULL,0,0,'2025-07-17 07:00:20','2025-07-17 15:44:43',NULL),(218,'6-60204','Komisi dan Fee','beban','','beban',NULL,0,0,'2025-07-17 07:53:09','2025-07-17 15:53:54',NULL),(219,'6-60234','Bonus','beban','','beban',NULL,0,0,'2025-07-19 03:02:49','2025-07-19 11:04:35',NULL),(220,'6-60104','Lembur','beban','','beban',NULL,0,0,'2025-07-19 03:04:45','2025-07-19 11:29:22',NULL),(221,'6-60220','Aktifasi Software','beban','','beban',NULL,0,0,'2025-07-21 03:38:43','2025-07-21 13:52:55',NULL),(222,'6-60214','Perizinan','beban','','beban',NULL,0,0,'2025-07-21 05:53:05','2025-07-21 14:01:45',NULL),(223,'7-70000','Pendapatan Bunga','pendapatan lainnya','','pendapatan',NULL,0,0,'2025-07-21 07:05:57','2025-07-21 15:07:07',NULL),(224,'8-80005','Beban Jasa Giro','beban lainnya','','beban',NULL,0,0,'2025-07-21 07:07:17','2025-07-21 15:10:54',NULL),(225,'6-60201','Hiburan','beban','','beban',NULL,0,0,'2025-07-21 08:53:02','2025-07-21 16:53:21',NULL),(226,'6-60102','Beban Frelance','beban','','beban',NULL,0,0,'2025-07-22 10:20:04','2025-07-22 18:21:00',NULL),(227,'6-60221','Beban Telephone','beban','','beban',NULL,0,0,'2025-07-24 10:58:47','2025-07-24 18:59:10',NULL),(228,'6-60227','Beban Perlangkapan Kantor','beban','','beban',NULL,0,0,'2025-07-25 07:53:34','2025-07-25 15:55:16',NULL);
/*!40000 ALTER TABLE `akuns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `akuntransactions`
--

DROP TABLE IF EXISTS `akuntransactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `akuntransactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `debet` varchar(255) NOT NULL,
  `kredit` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `akuntransactions`
--

LOCK TABLES `akuntransactions` WRITE;
/*!40000 ALTER TABLE `akuntransactions` DISABLE KEYS */;
INSERT INTO `akuntransactions` VALUES (1,'pemasukkan','Simpan ke','diterima dari'),(2,'pengeluaran','untuk','di ambil dari'),(3,'utang','simpan ke','utang dari'),(4,'bayar utang','diambil dari','bayar utang'),(5,'piutang','simpan ke','dari'),(6,'dibayar piutang','simpan ke','dari'),(7,'tambah modal','simpan ke','modal'),(8,'tarik modal','modal','diambil dari'),(9,'general','-','-');
/*!40000 ALTER TABLE `akuntransactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `akunusers`
--

DROP TABLE IF EXISTS `akunusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `akunusers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `akun_code` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `akunusers`
--

LOCK TABLES `akunusers` WRITE;
/*!40000 ALTER TABLE `akunusers` DISABLE KEYS */;
INSERT INTO `akunusers` VALUES (2,218,'1-10005'),(4,218,'1-10024'),(5,220,'1-10006'),(6,220,'1-10005'),(7,220,'1-10024'),(8,223,'1-10005'),(9,223,'1-10024');
/*!40000 ALTER TABLE `akunusers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alerts`
--

DROP TABLE IF EXISTS `alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alerts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `probe_id` bigint(20) unsigned DEFAULT NULL,
  `host` varchar(100) NOT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `status` enum('up','down') NOT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `probe_id` (`probe_id`),
  CONSTRAINT `alerts_ibfk_1` FOREIGN KEY (`probe_id`) REFERENCES `probes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alerts`
--

LOCK TABLES `alerts` WRITE;
/*!40000 ALTER TABLE `alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banks`
--

LOCK TABLES `banks` WRITE;
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
INSERT INTO `banks` VALUES (7,7,'Tunai Oleh Teknisi',NULL,'2022-01-26 16:14:43',NULL,NULL);
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (22,'C2025110897','supplier','Kantor ALus','08123456','tes1@gmail.com','Tanah Lot',NULL,'2025-11-08 06:22:14','2025-11-08 06:22:14','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customerlogs`
--

DROP TABLE IF EXISTS `customerlogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customerlogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `updated_by` varchar(255) NOT NULL,
  `topic` varchar(255) DEFAULT NULL,
  `updates` text NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customerlogs`
--

LOCK TABLES `customerlogs` WRITE;
/*!40000 ALTER TABLE `customerlogs` DISABLE KEYS */;
INSERT INTO `customerlogs` VALUES (1,2,'2026-02-07 14:37:32','duwija','customerdata','{\"id_sale\":{\"old\":0,\"new\":\"3\"},\"updated_by\":{\"old\":null,\"new\":\"duwija\"},\"updated_at\":{\"old\":\"2026-02-07T06:09:54.000000Z\",\"new\":\"2026-02-07 14:37:19\"}}','2026-02-07 14:37:32','2026-02-07 06:37:32',NULL),(2,2,'2026-02-14 19:50:14','duwija','customerdata','{\"Status\":{\"old\":\"Potensial\",\"new\":\"Inactive\"},\"updated_at\":{\"old\":\"2026-02-07T06:37:19.000000Z\",\"new\":\"2026-02-14 19:50:02\"}}','2026-02-14 19:50:14','2026-02-14 11:50:14',NULL);
/*!40000 ALTER TABLE `customerlogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(191) NOT NULL,
  `pppoe` varchar(255) NOT NULL,
  `password` varchar(225) DEFAULT NULL,
  `id_distrouter` int(11) DEFAULT NULL,
  `name` varchar(191) NOT NULL,
  `id_card` varchar(25) DEFAULT NULL,
  `contact_name` varchar(255) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone` varchar(191) NOT NULL,
  `id_plan` int(11) DEFAULT NULL,
  `id_distpoint` int(11) DEFAULT NULL,
  `id_status` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT 'return@alus.co.id',
  `address` varchar(191) DEFAULT NULL,
  `coordinate` varchar(191) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  `deleted_at` timestamp NULL DEFAULT NULL,
  `npwp` varchar(225) DEFAULT NULL,
  `tax` int(11) DEFAULT 0,
  `billing_start` date DEFAULT NULL,
  `id_olt` int(11) DEFAULT NULL,
  `id_onu` varchar(15) DEFAULT NULL,
  `id_sale` int(11) NOT NULL DEFAULT 0,
  `isolir_date` int(4) NOT NULL DEFAULT 21,
  `id_merchant` int(11) DEFAULT 1,
  `notification` int(11) NOT NULL DEFAULT 1,
  `ip` varchar(255) DEFAULT NULL,
  `portal_password` varchar(225) DEFAULT NULL COMMENT 'Customer portal login password',
  `remember_token` varchar(100) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_customer_name_unique` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (2,'KC260207319','duwija','123456',1,'Nama',NULL,'Duwija putra','1990-01-01','081805360534',2,1,3,'duwija@trikamedia.com','Jalan Telaga Ngembeng Gang Belibis no. 4 Desa Bugbug Kec. Karangasem Kab. Karangasem','-8.554541,115.110114',NULL,'duwija','duwija','2026-02-07 06:09:54','2026-02-16 01:51:23',NULL,NULL,11,'2026-02-07',NULL,NULL,3,21,1,1,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `parrent` int(255) DEFAULT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `sn` varchar(50) DEFAULT NULL,
  `owner` varchar(50) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `note` varchar(225) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distpointgroups`
--

DROP TABLE IF EXISTS `distpointgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distpointgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `capacity` int(11) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distpointgroups`
--

LOCK TABLES `distpointgroups` WRITE;
/*!40000 ALTER TABLE `distpointgroups` DISABLE KEYS */;
INSERT INTO `distpointgroups` VALUES (1,'OLT ZTE POP SERVER 1/2/1',128,'','2026-02-07 04:45:32','2026-02-07 12:45:32',NULL);
/*!40000 ALTER TABLE `distpointgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distpoints`
--

DROP TABLE IF EXISTS `distpoints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distpoints` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `id_site` int(11) NOT NULL,
  `ip` int(191) DEFAULT 0,
  `security` varchar(255) DEFAULT NULL,
  `parrent` int(11) DEFAULT NULL,
  `coordinate` varchar(225) DEFAULT NULL,
  `monitoring` tinyint(1) NOT NULL DEFAULT 0,
  `status` tinyint(1) DEFAULT NULL,
  `description` varchar(191) DEFAULT NULL,
  `distpointgroup_id` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `distpoints_name_unique` (`name`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distpoints`
--

LOCK TABLES `distpoints` WRITE;
/*!40000 ALTER TABLE `distpoints` DISABLE KEYS */;
INSERT INTO `distpoints` VALUES (1,'MS01',2,0,'-5',NULL,'-8.562636,115.106453',0,NULL,'-',1,'2026-02-07 04:48:48','2026-02-07 06:58:20',NULL),(2,'ODP 001',2,8,'-20',1,'-8.561840,115.111145',0,NULL,'-',1,'2026-02-07 04:51:12','2026-02-07 06:40:55',NULL);
/*!40000 ALTER TABLE `distpoints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `distrouters`
--

DROP TABLE IF EXISTS `distrouters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `distrouters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `web` int(10) NOT NULL DEFAULT 80,
  `user` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `note` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `distrouters`
--

LOCK TABLES `distrouters` WRITE;
/*!40000 ALTER TABLE `distrouters` DISABLE KEYS */;
INSERT INTO `distrouters` VALUES (1,'103.156.74.38','RO_SAMPLE',8787,9191,'remote','remote','CHR','2026-02-07 13:28:42','2026-02-07 05:28:42',NULL);
/*!40000 ALTER TABLE `distrouters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `files`
--

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'Management'),(2,'NOC'),(3,'Marketing'),(4,'Accounting'),(5,'Payment'),(6,'Teknisi'),(7,'Merchant'),(10,'HRD');
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `monthly_fee` int(11) NOT NULL,
  `periode` text NOT NULL,
  `description` text NOT NULL,
  `qty` int(11) NOT NULL,
  `amount` float NOT NULL,
  `tax` int(11) DEFAULT NULL,
  `tax_amount` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `created_by` text DEFAULT NULL,
  `updated_at` date NOT NULL,
  `payment_status` tinyint(1) NOT NULL DEFAULT 0,
  `tempcode` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES (1,2,0,'022026','Biaya Registasi',1,100000,NULL,0,'2026-02-07 14:39:12',NULL,'2026-02-07',3,'bb6fe3cffd1409deaf47e3914e5c85611cafdb10');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jurnals`
--

DROP TABLE IF EXISTS `jurnals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jurnals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) DEFAULT NULL,
  `date` date NOT NULL,
  `id_akun` varchar(11) NOT NULL,
  `kredit` int(11) NOT NULL DEFAULT 0,
  `debet` int(11) NOT NULL DEFAULT 0,
  `reff` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `memo` text DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `contact_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jurnals_akun_date` (`id_akun`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jurnals`
--

LOCK TABLES `jurnals` WRITE;
/*!40000 ALTER TABLE `jurnals` DISABLE KEYS */;
INSERT INTO `jurnals` VALUES (1,'88c1bdd284','2026-02-07','1-10100',0,111000,'bb6fe3cffd1409deaf47e3914e5c85611cafdb10','jumum','Invoice #6986de1769d88 | KC260207319 | Nama','Invoice #6986de1769d88 | KC260207319 | Nama',NULL,NULL,NULL,'2','2026-02-07 06:39:19','2026-02-07',NULL),(2,'88c1bdd284','2026-02-07','4-40000',100000,0,'bb6fe3cffd1409deaf47e3914e5c85611cafdb10','jumum','Invoice #6986de1769d88 | KC260207319 | Nama','Invoice #6986de1769d88 | KC260207319 | Nama',NULL,NULL,NULL,'2','2026-02-07 06:39:19','2026-02-07',NULL),(3,'88c1bdd284','2026-02-07','2-20500',11000,0,'bb6fe3cffd1409deaf47e3914e5c85611cafdb10','jumum','Invoice #6986de1769d88 | KC260207319 | Nama','Invoice #6986de1769d88 | KC260207319 | Nama',NULL,NULL,NULL,'2','2026-02-07 06:39:19','2026-02-07',NULL);
/*!40000 ALTER TABLE `jurnals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `map_layers`
--

DROP TABLE IF EXISTS `map_layers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `map_layers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) DEFAULT NULL,
  `type` varchar(191) NOT NULL,
  `group` varchar(191) DEFAULT NULL,
  `coordinates` text NOT NULL,
  `color` varchar(191) NOT NULL DEFAULT '#3388ff',
  `icon` varchar(50) DEFAULT 'pin',
  `weight` int(11) NOT NULL DEFAULT 3,
  `opacity` decimal(3,2) NOT NULL DEFAULT 0.60,
  `description` text DEFAULT NULL,
  `distance` decimal(10,2) DEFAULT NULL,
  `area` decimal(15,2) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `is_visible` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `map_layers_created_by_foreign` (`created_by`),
  CONSTRAINT `map_layers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `map_layers`
--

LOCK TABLES `map_layers` WRITE;
/*!40000 ALTER TABLE `map_layers` DISABLE KEYS */;
INSERT INTO `map_layers` VALUES (1,'Kabel 12 Core','polyline','Group Kabel 12 C','[[-8.56217233958757,115.10570135020248],[-8.562724020812515,115.1065594293964],[-8.56170553177256,115.10763202838882],[-8.560602165570074,115.10887624322001],[-8.560644602790864,115.11020626597059],[-8.561356503041027,115.11118529847833],[-8.561154926577215,115.11159288609544],[-8.564937119801439,115.1093136132366],[-8.567901297943177,115.11325603323976],[-8.568028607148834,115.11407120847394],[-8.565482414938916,115.11527251934545],[-8.565906781490906,115.11707448565271],[-8.566203837795596,115.11874774008088],[-8.561960154288089,115.12003485887178]]','#22c55e','pin',3,0.60,'🌐 Fiber: 12C | Aerial | Installed',3110.40,NULL,1,1,'2026-02-07 06:42:25','2026-02-07 06:43:13'),(2,'Group Kabel 12 C','group',NULL,'[]','#d32f2f','pin',3,0.60,'Group Background Color',NULL,NULL,1,1,'2026-02-07 06:43:07','2026-02-07 06:43:07'),(3,'OFFICR','marker',NULL,'[[-8.56217233958757,115.10570135020248]]','#3388ff','building',3,0.60,'office',NULL,NULL,1,1,'2026-02-07 06:43:44','2026-02-07 06:43:44');
/*!40000 ALTER TABLE `map_layers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `merchants`
--

DROP TABLE IF EXISTS `merchants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `merchants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `akun_code` varchar(255) DEFAULT NULL,
  `contact_name` varchar(50) NOT NULL,
  `id_user` int(11) NOT NULL,
  `payment_point` int(11) NOT NULL DEFAULT 0,
  `phone` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `coordinate` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `merchants`
--

LOCK TABLES `merchants` WRITE;
/*!40000 ALTER TABLE `merchants` DISABLE KEYS */;
INSERT INTO `merchants` VALUES (1,'OFFICE','1-10005','Office',0,1,'085792118777','Office','-8.62362087207041,115.1155368078099','Office','2025-07-29 16:19:20','2025-08-10 20:02:50',NULL);
/*!40000 ALTER TABLE `merchants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (27,'2014_10_12_000000_create_users_table',1),(28,'2019_08_19_000000_create_failed_jobs_table',1),(29,'2020_06_18_053901_create_customers_table',1),(30,'2020_06_18_165853_create_plans_table',1),(31,'2020_07_02_143448_create_sites_table',1),(32,'2020_08_14_134457_create_distpoints_table',1),(33,'2014_10_12_100000_create_password_resets_table',2),(34,'0000_00_00_000000_create_websockets_statistics_entries_table',3),(35,'2024_06_09_202916_create_jobs_table',4),(36,'2025_11_16_141234_create_tenants_table',5),(37,'2025_12_03_042213_add_payment_gateway_config_to_tenants_table',5),(38,'2026_01_27_000001_add_auth_fields_to_customers_table',6),(39,'2026_01_28_104134_create_map_layers_table',7),(40,'2026_02_02_000001_add_group_to_map_layers_table',8),(41,'2026_02_04_154306_add_parent_ticket_id_to_tickets_table',9);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oltonuprofiles`
--

DROP TABLE IF EXISTS `oltonuprofiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oltonuprofiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_olt` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `vlan` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oltonuprofiles`
--

LOCK TABLES `oltonuprofiles` WRITE;
/*!40000 ALTER TABLE `oltonuprofiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `oltonuprofiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oltonutypes`
--

DROP TABLE IF EXISTS `oltonutypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oltonutypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_olt` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oltonutypes`
--

LOCK TABLES `oltonutypes` WRITE;
/*!40000 ALTER TABLE `oltonutypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oltonutypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `olts`
--

DROP TABLE IF EXISTS `olts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `olts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `type` varchar(15) NOT NULL,
  `vendor` varchar(20) DEFAULT 'zte',
  `ip` varchar(20) NOT NULL,
  `port` int(11) NOT NULL DEFAULT 23,
  `user` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `community_ro` varchar(15) NOT NULL,
  `community_rw` varchar(15) NOT NULL,
  `snmp_port` int(11) NOT NULL DEFAULT 161,
  `created_at` datetime NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `olts`
--

LOCK TABLES `olts` WRITE;
/*!40000 ALTER TABLE `olts` DISABLE KEYS */;
/*!40000 ALTER TABLE `olts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) NOT NULL,
  `token` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES ('duwija.ptr@gmail.com','$2y$10$Uxv2BfRxLEa0hQ83ejUFIOxuSTZlxyDN2eY7UkjNKTzpvEfc/unwy','2021-01-01 02:59:25'),('ayutiaradewi16@gmail.com','$2y$10$Fzz3Eoo40nLx6FTlHJBzIOynLFs7.OxQDNr1LzKfPo58W2Tm5rFs.','2023-03-10 04:06:03'),('wynmega.agd@gmail.com','$2y$10$B1N7ck/uHZ9ImIxthcMjBuUfzfJ1065JzlK2g4LaZlMMu6T.XIWfK','2023-12-27 22:47:45'),('royhanmaulana321@gmail.com','$2y$10$lrXAdJLvkf42xwyvn2r48uctmxBjKXxffv3KpiwP4ncHYMFFvEmsu','2024-03-12 00:16:44'),('noc@trikamedia.com','$2y$10$2ZHhWP/dASESCBKhfgLlE.FfHhynkSV.KFUcYKAmUKjBFvhvbQx2O','2024-04-09 23:44:25'),('solemanhambu408@gmail.com','$2y$10$oLYcBOiEcxuN8UM1RrmjweM9LI9DaoZy16FYyPZaxUS3BwtINBYGS','2025-03-06 13:14:45'),('tmh@alus.co.id','$2y$10$e0Dj761n49OfVMXze9UaH.7ouj1a5Zb5Q7j1Y4/MqSx6m5NpK4DAq','2025-03-25 02:20:53'),('Lina@alus.co.id','$2y$10$xNbtic/dxRjYh3czOSNJUeweHXwipD.6etpHRyca2zvtPuVcrUDT.','2025-05-20 00:03:38');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('bank_va','ewallet','retail','qris','bumdes') NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `is_enabled` tinyint(1) DEFAULT 1,
  `display_order` int(11) DEFAULT 0,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
INSERT INTO `payment_methods` VALUES (1,'BUMDES','Bumdes / Payment Point','bumdes','fas fa-store',1,1,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(2,'BCAVA','BCA Virtual Account','bank_va','BCAVA.webp',1,2,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(3,'BNIVA','BNI Virtual Account','bank_va','BNIVA.webp',0,3,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(4,'BRIVA','BRI Virtual Account','bank_va','BRIVA.webp',0,4,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(5,'MANDIRIVA','Mandiri Virtual Account','bank_va','MANDIRIVA.webp',0,5,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(6,'PERMATAVA','Permata Virtual Account','bank_va','PERMATAVA.webp',0,6,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(7,'CIMBVA','CIMB Niaga Virtual Account','bank_va','CIMBVA.webp',0,7,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(8,'QRIS','QRIS','qris','QRIS.webp',1,8,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(9,'DANA','Dana E-Wallet','ewallet','DANA.webp',1,9,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(10,'OVO','OVO E-Wallet','ewallet','OVO.webp',1,10,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(11,'SHOPEEPAY','ShopeePay','ewallet','SHOPEEPAY.webp',0,11,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(12,'ALFAMART','Alfamart','retail','ALFAMART.webp',0,12,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15'),(13,'INDOMARET','Indomaret','retail','INDOMARET.webp',0,13,NULL,'2025-12-02 19:27:15','2025-12-02 19:27:15');
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pings`
--

DROP TABLE IF EXISTS `pings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `probe_id` bigint(20) unsigned DEFAULT NULL,
  `host` varchar(100) NOT NULL,
  `host_name` varchar(255) DEFAULT NULL,
  `is_up` tinyint(1) NOT NULL DEFAULT 0,
  `rtt_avg_ms` float DEFAULT NULL,
  `loss_percent` float DEFAULT NULL,
  `polled_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_host` (`host`),
  KEY `idx_probe_host` (`probe_id`,`host`),
  CONSTRAINT `fk_pings_probe` FOREIGN KEY (`probe_id`) REFERENCES `probes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pings`
--

LOCK TABLES `pings` WRITE;
/*!40000 ALTER TABLE `pings` DISABLE KEYS */;
/*!40000 ALTER TABLE `pings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `speed` varchar(191) NOT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(191) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `plans_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plans`
--

LOCK TABLES `plans` WRITE;
/*!40000 ALTER TABLE `plans` DISABLE KEYS */;
INSERT INTO `plans` VALUES (1,'Paket Karyawan','14M/14M 20M/20M 10500K/10500K 23/23 8 1750K/1750K',200000,'200000','2026-02-07 05:20:53','2026-02-07 05:20:53',NULL),(2,'paket Hemat','14M/14M 20M/20M 10500K/10500K 23/23 8 1750K/1750K',0,'Imported from Mikrotik RO_SAMPLE','2026-02-07 05:51:53','2026-02-07 05:51:53',NULL);
/*!40000 ALTER TABLE `plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `probes`
--

DROP TABLE IF EXISTS `probes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `probes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `probe_id` varchar(100) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `type` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `probe_id` (`probe_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `probes`
--

LOCK TABLES `probes` WRITE;
/*!40000 ALTER TABLE `probes` DISABLE KEYS */;
/*!40000 ALTER TABLE `probes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `full_name` text DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `sale_type` varchar(255) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `photo` varchar(191) DEFAULT 'user.png',
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (1,'Office','Office','2024-09-10',NULL,'Full Time','2024-09-10','penelokan','6281805360534','user.png','office@twinnet.trikamedia.com',NULL,'$2y$10$IPWIPgYJBEXZdDwp8YxSb.eZc/giGp97.sNGIwzp.JMOpmRLBoPgO',NULL,NULL,'Sales Kantor','2024-09-09 23:46:20','2025-08-01 06:39:47','2025-08-01 06:39:47'),(3,'Office','Office','2026-02-13',NULL,'Full Time','2026-02-14','Jalan Telaga Ngembeng Gang Belibis no. 4 Desa Bugbug Kec. Karangasem Kab. Karangasem2','6281805360534','1770446093.jpg','duwija.ptr@gmail.com',NULL,'$2y$10$HifFcTXge2lh63I4YRBQVuZtyF/j96sNvtRmo9gWCY.rYc8Wex8.i',NULL,NULL,'test','2026-02-07 06:29:00','2026-02-07 06:34:53',NULL);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `location` varchar(191) NOT NULL,
  `coordinate` varchar(191) NOT NULL,
  `description` varchar(191) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sites_name_unique` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (2,'OFFICE','POP','-8.623960313287684,115.11547243479355','POP FO','2024-12-13 16:54:42','2025-08-01 06:24:55',NULL),(9,'POP B','SESEH','-8.64516948020833,115.11430835608108','POP FO Seseh','2025-07-31 14:21:19','2026-02-07 05:21:38','2026-02-07 05:21:38'),(10,'POP C','Br. Pempatan Munggu','-8.620778039904037,115.12499964121444','POP WIRELES MUNGGU','2025-08-01 06:28:50','2026-02-07 05:21:51','2026-02-07 05:21:51'),(11,'POP D','JL Munggu Cempaka','-8.61303439608895,115.13710176828964','POP Wireles Bantas','2025-08-01 06:30:09','2026-02-07 05:21:59','2026-02-07 05:21:59'),(12,'POP E','Jl. Pantai Mengening','-8.640783486228099,115.1067820775853','POP Wireles Mengening','2025-08-01 06:31:37','2026-02-07 05:22:06','2026-02-07 05:22:06');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statuscustomers`
--

DROP TABLE IF EXISTS `statuscustomers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statuscustomers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `deleted_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statuscustomers`
--

LOCK TABLES `statuscustomers` WRITE;
/*!40000 ALTER TABLE `statuscustomers` DISABLE KEYS */;
INSERT INTO `statuscustomers` VALUES (1,'Potensial','#3bacd9','0000-00-00 00:00:00'),(2,'Active','#2bd93a','0000-00-00 00:00:00'),(3,'Inactive','#959c9a','0000-00-00 00:00:00'),(4,'Block','#e32510','0000-00-00 00:00:00'),(5,'Company_Properti','#8866aa','0000-00-00 00:00:00');
/*!40000 ALTER TABLE `statuscustomers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suminvoices`
--

DROP TABLE IF EXISTS `suminvoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suminvoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_customer` int(11) NOT NULL,
  `number` varchar(50) DEFAULT '0',
  `date` date DEFAULT NULL,
  `tax` int(11) NOT NULL DEFAULT 11,
  `pph` int(11) NOT NULL DEFAULT 0,
  `tempcode` varchar(255) NOT NULL,
  `payment_status` int(255) NOT NULL DEFAULT 3,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `total_amount` int(11) DEFAULT NULL,
  `payment_id` varchar(200) DEFAULT NULL,
  `recieve_payment` int(11) DEFAULT NULL,
  `payment_point` varchar(255) DEFAULT NULL,
  `verify` tinyint(1) NOT NULL DEFAULT 0,
  `note` varchar(500) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `merchant_fee` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suminvoices`
--

LOCK TABLES `suminvoices` WRITE;
/*!40000 ALTER TABLE `suminvoices` DISABLE KEYS */;
INSERT INTO `suminvoices` VALUES (1,2,'6986de1769d88','2026-02-07',11,0,'bb6fe3cffd1409deaf47e3914e5c85611cafdb10',0,NULL,NULL,'2026-02-07 06:39:19','2026-02-07 14:39:19',NULL,NULL,111000,'empty',NULL,NULL,0,NULL,NULL,'2026-02-20',0);
/*!40000 ALTER TABLE `suminvoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (25,'Follow Up','2025-04-08 19:45:31','2025-04-08 19:45:31'),(26,'Project In House','2025-05-09 06:49:50','2025-05-09 06:49:50'),(27,'Noc','2025-05-25 14:58:35','2025-05-25 14:58:35'),(28,'Pasang Baru Fo','2025-08-07 13:00:21','2025-08-07 13:00:21'),(29,'Migrasi','2025-09-19 04:00:55','2025-09-19 04:00:55'),(30,'paralel','2025-10-20 10:12:34','2025-10-20 10:12:34'),(31,'CCTV','2025-10-20 10:20:14','2025-10-20 10:20:14'),(32,'Pasang Baru Wireles','2025-10-24 11:27:33','2025-10-24 11:27:33'),(33,'Kabel Los','2025-10-31 13:55:29','2025-10-31 13:55:29');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenants` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `domain` varchar(191) NOT NULL,
  `app_name` varchar(191) NOT NULL,
  `signature` varchar(191) NOT NULL,
  `rescode` varchar(10) NOT NULL,
  `db_host` varchar(191) NOT NULL DEFAULT '127.0.0.1',
  `db_port` varchar(191) NOT NULL DEFAULT '3306',
  `db_database` varchar(191) NOT NULL,
  `db_username` varchar(191) NOT NULL,
  `db_password` varchar(191) NOT NULL,
  `mail_from` varchar(191) DEFAULT NULL,
  `whatsapp_token` text DEFAULT NULL,
  `xendit_key` text DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `payment_bumdes_enabled` tinyint(4) NOT NULL DEFAULT 1,
  `payment_winpay_enabled` tinyint(4) NOT NULL DEFAULT 1,
  `payment_tripay_enabled` tinyint(4) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenants_domain_unique` (`domain`),
  UNIQUE KEY `tenants_rescode_unique` (`rescode`),
  KEY `tenants_domain_index` (`domain`),
  KEY `tenants_rescode_index` (`rescode`),
  KEY `tenants_is_active_index` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_steps`
--

DROP TABLE IF EXISTS `ticket_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_steps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  CONSTRAINT `ticket_steps_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_steps`
--

LOCK TABLES `ticket_steps` WRITE;
/*!40000 ALTER TABLE `ticket_steps` DISABLE KEYS */;
INSERT INTO `ticket_steps` VALUES (11,76,'Pengecekan',1,'2026-02-15 03:14:34','2026-02-15 03:14:34'),(12,76,'Start',2,'2026-02-15 03:14:34','2026-02-15 03:14:34'),(13,76,'Konfirmasi',3,'2026-02-15 03:14:34','2026-02-15 03:14:34'),(14,76,'Perbaikan',4,'2026-02-15 03:14:34','2026-02-15 03:14:34'),(15,76,'Monitoring',5,'2026-02-15 03:14:34','2026-02-15 03:14:34'),(16,77,'Start',1,'2026-02-15 15:27:30','2026-02-15 15:27:30'),(17,77,'Inprogress',2,'2026-02-15 15:27:30','2026-02-15 15:27:30'),(18,77,'Complete',3,'2026-02-15 15:27:30','2026-02-15 15:27:30'),(19,77,'Finish',4,'2026-02-15 15:27:30','2026-02-15 15:27:30'),(21,78,'Start',2,'2026-02-16 01:58:37','2026-02-16 01:58:37'),(22,78,'Konfirmasi',3,'2026-02-16 01:58:37','2026-02-16 01:58:37'),(23,78,'Perbaikan',4,'2026-02-16 01:58:37','2026-02-16 01:58:37'),(24,78,'Monitoring',5,'2026-02-16 01:58:37','2026-02-16 01:58:37'),(25,78,'Finish',6,'2026-02-16 02:06:18','2026-02-16 02:06:18');
/*!40000 ALTER TABLE `ticket_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketcategories`
--

DROP TABLE IF EXISTS `ticketcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketcategories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `workflow` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketcategories`
--

LOCK TABLES `ticketcategories` WRITE;
/*!40000 ALTER TABLE `ticketcategories` DISABLE KEYS */;
INSERT INTO `ticketcategories` VALUES (1,'Router Problem','[\"Start\",\"Pengecekan\",\"Konfirmasi\",\"Perbaikan\",\"Monitoring\"]',NULL,'2026-02-16 02:03:27',NULL),(2,'Weak Signal',NULL,NULL,NULL,NULL),(3,'Fiber Problem',NULL,NULL,NULL,NULL),(4,'interference',NULL,NULL,NULL,NULL),(5,'Upstrame Problem',NULL,NULL,NULL,NULL),(6,'Internal Maintenance',NULL,NULL,NULL,NULL),(7,'Billing ',NULL,NULL,NULL,NULL),(8,'Information',NULL,NULL,NULL,NULL),(9,'New Client Installation',NULL,NULL,NULL,NULL),(10,'Change Wifi Password',NULL,NULL,NULL,NULL),(11,'Additional Installation',NULL,NULL,NULL,NULL),(12,'Device Relocation',NULL,NULL,NULL,NULL),(13,'Take Down',NULL,NULL,NULL,NULL),(14,'Relay Problem',NULL,NULL,NULL,NULL),(15,'Looping',NULL,NULL,NULL,NULL),(16,'MC Problem',NULL,NULL,NULL,NULL),(17,'Link Migration',NULL,NULL,NULL,NULL),(18,'Speedtest Issue',NULL,NULL,NULL,NULL),(19,'Survey',NULL,NULL,NULL,NULL),(20,'ODP Activation',NULL,NULL,NULL,NULL),(21,'ODP Maintenance',NULL,NULL,NULL,NULL),(22,'CCTV Maintenance',NULL,NULL,NULL,NULL),(23,'Development',NULL,NULL,NULL,NULL),(24,'Customer Terminate',NULL,NULL,NULL,NULL),(25,'Customer Relocation',NULL,NULL,NULL,NULL),(26,'New Installation ( Non Customer )',NULL,NULL,NULL,NULL),(27,'ODP Problem',NULL,NULL,NULL,NULL),(28,'MS Problem',NULL,NULL,NULL,NULL),(29,'POP Problem',NULL,NULL,NULL,NULL),(30,'Repeater Problem',NULL,NULL,NULL,NULL),(31,'C-Data Problem',NULL,NULL,NULL,NULL),(32,'ZTE Problem\r\n',NULL,NULL,NULL,NULL),(33,'Zimmlink Problem',NULL,NULL,NULL,NULL),(34,'Gamas',NULL,NULL,NULL,NULL),(35,'Installation Problem\r\n',NULL,NULL,NULL,NULL),(36,'Selective Browsing Issue\r\n',NULL,NULL,'2025-12-02 17:57:05','2025-12-02 17:57:05'),(37,'Non-ISP Issue',NULL,NULL,'2025-12-02 17:54:07','2025-12-02 17:54:07'),(38,'Complaint Non-Teknis\r\n',NULL,NULL,NULL,NULL),(39,'Link Connection',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ticketcategories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketdetails`
--

DROP TABLE IF EXISTS `ticketdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticketdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_ticket` int(11) NOT NULL,
  `description` longtext DEFAULT NULL,
  `updated_by` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketdetails`
--

LOCK TABLES `ticketdetails` WRITE;
/*!40000 ALTER TABLE `ticketdetails` DISABLE KEYS */;
INSERT INTO `ticketdetails` VALUES (1,76,'Workflow pindah ke step: <b>Start</b>','duwija','2026-02-15 11:14:54','2026-02-15 11:14:54'),(2,77,'Workflow pindah ke step: <b>Inprogress</b>','duwija','2026-02-15 23:27:42','2026-02-15 23:27:42'),(3,77,'Workflow pindah ke step: <b>Finish</b>','duwija','2026-02-15 23:27:52','2026-02-15 23:27:52'),(4,77,'<p> Status changed from Inprogress to Close</p>','duwija','2026-02-15 23:28:07','2026-02-15 23:28:07'),(5,78,'Workflow pindah ke step: <b>Start</b>','duwija','2026-02-16 10:02:43','2026-02-16 10:02:43'),(6,78,'Workflow pindah ke step: <b>Konfirmasi</b>','duwija','2026-02-16 10:04:39','2026-02-16 10:04:39'),(7,78,'Workflow pindah ke step: <b>Monitoring</b>','duwija','2026-02-16 10:05:31','2026-02-16 10:05:31'),(8,78,'<p> Status changed from Inprogress to Close</p>','duwija','2026-02-16 10:06:18','2026-02-16 10:06:18');
/*!40000 ALTER TABLE `ticketdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_ticket_id` bigint(20) unsigned DEFAULT NULL,
  `ticket_type` varchar(50) NOT NULL DEFAULT 'standalone' COMMENT 'standalone, parent, child',
  `id_customer` int(11) NOT NULL,
  `called_by` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `id_categori` int(11) NOT NULL,
  `tittle` varchar(255) NOT NULL,
  `description` longtext DEFAULT NULL,
  `assign_to` int(11) NOT NULL,
  `member` varchar(255) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `create_by` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `solved_at` datetime DEFAULT NULL,
  `current_step_id` int(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tickets_parent_ticket_id_foreign` (`parent_ticket_id`),
  CONSTRAINT `tickets_parent_ticket_id_foreign` FOREIGN KEY (`parent_ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (76,NULL,'parent',2,'Duwija putra','081805360534','Close',1,'Installasi','<p>Tolong bantu installasi</p>\n',1,'','2026-02-13','14:37:00','duwija','2026-02-07 06:38:32','2026-02-15 15:28:07',NULL,12),(77,76,'child',2,'Duwija putra','081805360534','Close',19,'Survey','<p>dsdsd</p>\n',1,'','2026-02-15','11:15:00','duwija','2026-02-15 03:16:35','2026-02-15 15:28:07',NULL,19),(78,NULL,'standalone',2,'Duwija putra','081805360534','Close',1,'test','<p>test</p>\n',1,'duwija','2026-02-16','09:52:00','duwija','2026-02-16 01:52:30','2026-02-16 02:06:18',NULL,25);
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickettags`
--

DROP TABLE IF EXISTS `tickettags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickettags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickettags`
--

LOCK TABLES `tickettags` WRITE;
/*!40000 ALTER TABLE `tickettags` DISABLE KEYS */;
INSERT INTO `tickettags` VALUES (1,76,27,'2026-02-07 06:38:32'),(2,78,27,'2026-02-16 01:52:30');
/*!40000 ALTER TABLE `tickettags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) NOT NULL,
  `id_group` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
INSERT INTO `usergroups` VALUES (1,1,2);
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `full_name` text DEFAULT NULL,
  `privilege` varchar(50) NOT NULL DEFAULT 'user',
  `date_of_birth` date DEFAULT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `employee_type` varchar(255) DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `address` varchar(191) DEFAULT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `photo` varchar(191) DEFAULT 'user.png',
  `email` varchar(191) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `admin_fee` int(11) DEFAULT 0,
  `id_merchant` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_name_unique` (`name`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=225 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'duwija','I Nengah Duwija Putra','admin','1985-11-15','Network Engineer','Full Time','2021-09-14','tabanan','081805360534','user_1770179395_6982cb4320d98.jpeg','duwija.ptr@gmail.com',NULL,'$2y$12$BC3Gx5UQtOALCkmop/DOausfvy1gfbViKU7JYfObQhevMQdISi6wm','1WPfoyTBvRfkDtnTZf39kj6H04KFXgtrLie6UfE1oclsPmZt469rR6Dudv1w',NULL,NULL,NULL,'2021-01-01 00:58:49','2026-02-04 04:29:55',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `walogs`
--

DROP TABLE IF EXISTS `walogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `walogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session` varchar(100) NOT NULL,
  `number` varchar(255) NOT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `direction` enum('in','out') NOT NULL DEFAULT 'out',
  `message` text DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `error` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_walogs_message_id` (`message_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `walogs`
--

LOCK TABLES `walogs` WRITE;
/*!40000 ALTER TABLE `walogs` DISABLE KEYS */;
INSERT INTO `walogs` VALUES (1,'wa_adiyasa','6281805360534',NULL,'out','*[Informasi Pembayaran Internet]*\n\nYth. Nama,\n\nTagihan Anda dengan Customer ID (CID) *KC260207319* telah diterbitkan.\n*Total Tagihan:* Rp.111.000\n*Batas Pembayaran:* 2026-02-20\n\nUntuk informasi lebih lanjut, silakan klik link berikut:\nhttp://adiyasa.alus.co.id/invoice/cst/eyJpdiI6IkVDRmlJaTVlWVl0YkxDKzVMVWV1YkE9PSIsInZhbHVlIjoiMjBpTkdoamNOYVRDei9kdFQ2K1p2UT09IiwibWFjIjoiZTVhNmYzN2ZlNzZmMGUyMmRmOGNiYThiNjdjOGZjYmI0MmZhYTQwNmZiMmE4NzVkODk2ZWY4NTIzYzBkM2NmZSIsInRhZyI6IiJ9\n\nJika sudah melakukan pembayaran, abaikan pesan ini.\nJika ada pertanyaan, hubungi CS kami di 085792118777 / 087860270223\n\nKencana Alusnet','http_error',NULL,'2026-02-07 14:39:19','2026-02-07 14:39:19');
/*!40000 ALTER TABLE `walogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `websockets_statistics_entries`
--

DROP TABLE IF EXISTS `websockets_statistics_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `websockets_statistics_entries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `app_id` varchar(191) NOT NULL,
  `peak_connection_count` int(11) NOT NULL,
  `websocket_message_count` int(11) NOT NULL,
  `api_message_count` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `websockets_statistics_entries`
--

LOCK TABLES `websockets_statistics_entries` WRITE;
/*!40000 ALTER TABLE `websockets_statistics_entries` DISABLE KEYS */;
/*!40000 ALTER TABLE `websockets_statistics_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_steps`
--

DROP TABLE IF EXISTS `workflow_steps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflow_steps` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workflow_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_workflow_steps_workflow` (`workflow_id`),
  CONSTRAINT `fk_workflow_steps_workflow` FOREIGN KEY (`workflow_id`) REFERENCES `workflows` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_steps`
--

LOCK TABLES `workflow_steps` WRITE;
/*!40000 ALTER TABLE `workflow_steps` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_steps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflows`
--

DROP TABLE IF EXISTS `workflows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workflows` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflows`
--

LOCK TABLES `workflows` WRITE;
/*!40000 ALTER TABLE `workflows` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-16 12:02:14
